//============================================================================
// Name        : king_tut.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {

	int x = 9;

	//other comparison signs
	//==, <=, >=, <, and >
	if (x==8)
	{
		cout << "X matches with a number assigned to it!!" << endl;
	}

	else
	{
		cout << "X does not match!!" << endl;
	}

	return 0;
}
