#include <iostream>
using namespace std;

int main(){
//Dynamic Memory: Memory being allocated or changed during when program runs
//Usually the amount of Memory is used before the program runs
//Runtime: How long the program runs
//How to implement dynamic memory?

//1. Declare a pointer variable
	int *x;
//2. Set it equal to new [datatype][number of data you want to put in]
	x = new int [3];
	x[0] = 2;
	cout << x[0] << endl;
//3. Once you are done making use of that pointer variable use
//delete[] [pointer variable name]
	,delete [] x;
}
