//============================================================================
// Name        : king_tut.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	//boolean variable
	bool ishere = false;


	if (ishere)//same as ishere == true
	{
		cout << "is here" << endl;
	}

	else
	{
		cout << "not here" << endl;
	}

	return 0;
}
