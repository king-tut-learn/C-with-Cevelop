#include<iostream>
#include <cmath>

using namespace std;

int main(){
	cout << pow(2, 3) << endl;
	return 0;
}

