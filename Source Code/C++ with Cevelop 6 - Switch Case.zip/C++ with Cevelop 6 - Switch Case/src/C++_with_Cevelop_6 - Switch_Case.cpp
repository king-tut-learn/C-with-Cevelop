//============================================================================
// Name        : king_tut.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {

	int x = 7;


	switch(x)
	{
	case 7:
		cout << "x equals 7!!" << endl;
		break;
	case 8:
		cout << "x equals 7!!" << endl;
		break;

	default:
		cout << "x does not equal anything!!" << endl;
		break;
	}

	return 0;
}
