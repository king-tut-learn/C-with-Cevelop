//============================================================================
// Name        : king_tut.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	int x = 2;
	int y = 8;

	//i have added two float variables for division
	float a = 2;
	float b = 8;

	cout << x + y << endl;
	cout << x - y << endl;
	cout << x * y << endl;
	cout << a / b << endl;

	cout << 3 + 1 << endl;
	cout << 3 - 1 << endl;
	cout << 3 * 1 << endl;
	cout << 3.0 / 1.0 << endl;

	return 0;
}
