#include<iostream>

using namespace std;

string sentence = "I am a variable!!";
void print()
{
	cout << sentence << endl;
}

int main(){
	string word = "Local";

	cout << word << endl;

	return 0;
}
