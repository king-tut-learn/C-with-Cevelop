//============================================================================
// Name        : king_tut.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {

	for (int i = 0; i < 4; i = i + 1)
	{
		cout << i << endl;

	}

	for (int j = 0; j < 4; j = j + 1)
	{
		cout << "text" << endl;
	}

	return 0;
}
