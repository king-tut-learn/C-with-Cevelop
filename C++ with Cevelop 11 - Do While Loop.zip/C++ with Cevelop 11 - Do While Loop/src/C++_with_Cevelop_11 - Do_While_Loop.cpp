//============================================================================
// Name        : king_tut.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
//int, double, float, char, string

	int x;
	x = 12;

	double y = 12.7;
	float z,a;

	char c = '!';

	string words = "King Tut Rocks";

	cout << x << endl;

	return 0;
}
